#pragma once

#include <stdbool.h>

#ifdef __CYGWIN__
extern bool bQuit;
#endif
int main(int argc, char *argv[]);
