
#ifndef __PATHNAMES_H__
#define __PATHNAMES_H__ 1

#ifdef HAVE_PATHS_H
# include <paths.h>
#endif

#ifndef _PATH_DEVNULL
# define _PATH_DEVNULL "/dev/null"
#endif

#endif
