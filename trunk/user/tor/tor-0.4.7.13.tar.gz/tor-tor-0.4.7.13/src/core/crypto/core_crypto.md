@dir /core/crypto
@brief core/crypto: Tor-specific cryptography

This module implements Tor's circuit-construction crypto and Tor's
relay crypto.

