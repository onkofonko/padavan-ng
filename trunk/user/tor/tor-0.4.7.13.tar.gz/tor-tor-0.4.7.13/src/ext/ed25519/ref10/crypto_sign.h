/* Added for Tor */
#define crypto_sign ed25519_ref10_sign
#define crypto_sign_keypair ed25519_ref10_keygen
#define crypto_sign_seckey ed25519_ref10_seckey
#define crypto_sign_seckey_expand ed25519_ref10_seckey_expand
#define crypto_sign_pubkey ed25519_ref10_pubkey
#define crypto_sign_open ed25519_ref10_open

#include "ed25519_ref10.h"
