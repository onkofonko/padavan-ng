@dir /feature/client
@brief feature/client: Client-specific code

(There is also a bunch of client-specific code in other modules.)

