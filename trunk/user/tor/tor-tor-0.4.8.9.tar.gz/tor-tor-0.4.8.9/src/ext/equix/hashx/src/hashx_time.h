/* Copyright (c) 2020 tevador <tevador@gmail.com> */
/* See LICENSE for licensing information */

#ifndef HASHX_TIME_H
#define HASHX_TIME_H

double hashx_time(void);

#endif
