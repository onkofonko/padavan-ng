@dir /app/config
@brief app/config: Top-level configuration code

Refactoring this module is a work in progress, see
[ticket 29211](https://bugs.torproject.org/tpo/core/tor/29211)
