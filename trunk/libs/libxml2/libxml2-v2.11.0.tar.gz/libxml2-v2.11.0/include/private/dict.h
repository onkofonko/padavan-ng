#ifndef XML_DICT_H_PRIVATE__
#define XML_DICT_H_PRIVATE__

XML_HIDDEN int
__xmlInitializeDict(void);
XML_HIDDEN void
xmlCleanupDictInternal(void);
XML_HIDDEN int
__xmlRandom(void);

#endif /* XML_DICT_H_PRIVATE__ */
